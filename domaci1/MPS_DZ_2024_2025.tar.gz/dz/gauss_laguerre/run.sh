#! /bin/bash
#
./binc/ccn_rule 99 -10 +10 ccn_o99
./binc/ccn_rule 999 -100 +100 ccn_o999
./binc/ccn_rule 2999 -100 +100 ccn_o2999
